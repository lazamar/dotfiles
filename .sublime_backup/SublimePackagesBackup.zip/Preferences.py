import sublime
import sublime_plugin


class PlusLineCommand(sublime_plugin.TextCommand):
	def run(self, edit, lines = 10):
		(row,col) = self.view.rowcol(self.view.sel()[0].begin())

		# Prevent jumping from the top to the bottom of the file
		newLineNumber = max(1, row+1 + lines)

		self.view.run_command("goto_line", {"line": newLineNumber})
